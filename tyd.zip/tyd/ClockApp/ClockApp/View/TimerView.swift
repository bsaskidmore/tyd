import SwiftUI

struct TimerView: View {
    @ObservedObject private var viewModel: TimerViewModel = TimerViewModel()
    @State private var showingTimeSelection = false
    
    // Define state variables for hours, minutes, and seconds
    @State private var selectedHours: Int = 0
    @State private var selectedMinutes: Int = 0
    @State private var selectedSeconds: Int = 0
    
    var body: some View {
        ZStack {
            Color.backgroundColor.ignoresSafeArea()
            GeometryReader { geometryReader in
                VStack {
                    // Clock and Timer Hands
                    let width = geometryReader.size.width - 32
                    let numberWidth = width - 40
                    
                    ZStack {
                        ClockView(count: 60, longDivider: 5, longTickHeight: 14, tickHeight: 8, tickWidth: 2, highlightedColorDivider: 20, highlightedColor: .clockHighlightedLineColor, normalColor: .clockLineColor)
                            .frame(width: width, height: width)

                        NumberView(numbers: getNumbers(count: 12), textColor: .clockTextColor, font: .clockText)
                            .frame(width: numberWidth, height: numberWidth)

                        TimerHandView(remainingTime: $viewModel.remainingTime, totalDuration: viewModel.totalDuration, width: width, handType: .minute)
                        TimerHandView(remainingTime: $viewModel.remainingTime, totalDuration: viewModel.totalDuration, width: width, handType: .second)
                        
                    }
                    // Numerical Countdown Display
                    Text(formatTime(viewModel.remainingTime))
                                            .font(.title)
                                            .padding(.top, 20) // Adjust padding as needed
                    
                    // Start/Stop/Reset Buttons
                    HStack {
                        Button("Start") { viewModel.startTimer() }
                            .buttonStyle(ActionButtonStyle(textColor: .white, backgroundColor: .blue))
                        Button("Stop") { viewModel.stopTimer() }
                            .buttonStyle(ActionButtonStyle(textColor: .white, backgroundColor: .blue))
                        Button("Reset") { viewModel.resetTimer() }
                            .buttonStyle(ActionButtonStyle(textColor: .white, backgroundColor: .blue))
                    }
                    .padding(.top, 20)

                    // Button to Set Initial Time
                    Button("Set Timer") { showingTimeSelection = true }
                        .sheet(isPresented: $showingTimeSelection) {
                            CountdownTimeSelectionView(hours: $selectedHours, minutes: $selectedMinutes, seconds: $selectedSeconds, onSave: {
                                let totalSeconds = selectedHours * 3600 + selectedMinutes * 60 + selectedSeconds
                                viewModel.setTimerDuration(totalSeconds)
                                showingTimeSelection = false
                            }, onCancel: {
                                showingTimeSelection = false
                            })
                        }
                }
            }
        }
    }

    private func getNumbers(count: Int) -> [Int] {
        (1...count).map { $0 }
    }
    private func formatTime(_ time: TimeInterval) -> String {
            let hours = Int(time) / 3600
            let minutes = Int(time) / 60 % 60
            let seconds = Int(time) % 60
            return String(format: "%02i:%02i:%02i", hours, minutes, seconds)
        }
}

struct CountdownTimeSelectionView: View {
    @Binding var hours: Int
    @Binding var minutes: Int
    @Binding var seconds: Int
    var onSave: () -> Void
    var onCancel: () -> Void

    var body: some View {
        NavigationView {
            Form {
                Picker("Hours", selection: $hours) {
                    ForEach(0..<24, id: \.self) { Text("\($0) hr").tag($0) }
                }
                Picker("Minutes", selection: $minutes) {
                    ForEach(0..<60, id: \.self) { Text("\($0) min").tag($0) }
                }
                Picker("Seconds", selection: $seconds) {
                    ForEach(0..<60, id: \.self) { Text("\($0) sec").tag($0) }
                }
                HStack {
                    Button("Cancel", action: onCancel)
                    Spacer()
                    Button("Save", action: onSave)
                }
            }
            .navigationBarTitle("Set Timer", displayMode: .inline)
        }
    }
}

// TimerHandView, ClockView, and NumberView need to be defined
// TimerViewModel needs to handle the timer logic
