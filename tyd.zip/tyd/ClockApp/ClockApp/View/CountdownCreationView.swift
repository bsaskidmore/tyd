import SwiftUI

struct CountdownCreationView: View {
    @Binding var isPresented: Bool
    @State private var hour: Int = 0
    @State private var minute: Int = 0
    @State private var second: Int = 0

    var onSave: (_ totalSeconds: Int) -> Void

    var body: some View {
        NavigationView {
            Form {
                Picker("Hour", selection: $hour) {
                    ForEach(0..<24, id: \.self) { hour in
                        Text("\(hour)").tag(hour)
                    }
                }
                
                Picker("Minute", selection: $minute) {
                    ForEach(0..<60, id: \.self) { minute in
                        Text(String(format: "%02d", minute)).tag(minute)
                    }
                }

                Picker("Second", selection: $second) {
                    ForEach(0..<60, id: \.self) { second in
                        Text(String(format: "%02d", second)).tag(second)
                    }
                }

                Button("Set Timer") {
                    let totalSeconds = hour * 3600 + minute * 60 + second
                    onSave(totalSeconds)
                    isPresented = false
                }
            }
            .navigationBarTitle("Set Timer", displayMode: .inline)
            .navigationBarItems(trailing: Button("Cancel") {
                isPresented = false
            })
        }
    }
}
