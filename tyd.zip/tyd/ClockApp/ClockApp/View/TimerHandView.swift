import SwiftUI

enum TimerHandType {
    case minute, second
}

struct TimerHandView: View {
    @Binding var remainingTime: TimeInterval
    let totalDuration: TimeInterval
    let width: CGFloat
    let handType: TimerHandType

    var body: some View {
        let handLength = handType == .minute ? width * 0.5 : width * 0.75
        let handColor: Color = handType == .minute ? .needleGeneral : .needleCurrentLap

        let angle = calculateHandAngle()

        return NeedleView(width: 8, height: handLength, color: handColor, bottomLineHeight: Constraint.needleViewBottomLineHeight)
            .rotationEffect(.degrees(angle))
    }

    private func calculateHandAngle() -> Double {
        // Calculates the angle for the hand based on remaining time and total duration
        let fraction: Double
        switch handType {
        case .minute:
            fraction = (remainingTime / 60).truncatingRemainder(dividingBy: 60) / 60
        case .second:
            fraction = remainingTime.truncatingRemainder(dividingBy: 60) / 60
        }
        // Convert fraction of time to degrees (360 degrees in a circle)
        return fraction * 360 - 90 // Adjust for the starting position
    }
}



