import SwiftUI

struct ContentView: View {
    @StateObject var viewModel = AlarmWatchViewModel() // Initialize the view model

    var body: some View {
        TabView {
            AlarmWatchView(viewModel: viewModel) // Pass the viewModel to your AlarmWatchView
                .tabItem {
                    Image(systemName: "alarm")
                    Text("Alarm")
                }
            StopWatchView()
                .tabItem {
                    Image(systemName: "stopwatch")
                    Text("Stopwatch")
                }
            TimeWatchView()
                .tabItem {
                    Image(systemName: "clock")
                    Text("International")
                }
            TimerView() // Instantiate TimerView
                .tabItem {
                    Image(systemName: "timer")
                    Text("Timer")
                }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
