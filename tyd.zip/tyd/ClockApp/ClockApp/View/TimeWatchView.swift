import SwiftUI

struct TimeWatchView: View {
    @State var current_Time = Time(min: 0, sec: 0, hour: 0)
    @State var receiver = Timer.publish(every: 1, on: .current, in: .default).autoconnect()
    @State private var selectedTimeZone = TimeZone.current
    @State private var showingTimeZonePicker = false
//    var body: some View {
//        ZStack {
//            Color.backgroundColor.ignoresSafeArea()
//            GeometryReader { geometryReader in
//                VStack{
//                    // Clock UI Components
//                    createClockUI(geometryReader: geometryReader)
//
//                    // Timezone Selection Button
//                    Button("Select Timezone") {
//                        showingTimeZonePicker = true
//                    }
//                    .sheet(isPresented: $showingTimeZonePicker) {
//                        TimeZonePicker(selectedTimeZone: $selectedTimeZone)
//                    }
//                    // Display Selected Time Zone
//                    Text(selectedTimeZone.identifier)
//                        .font(.subheadline)
//                        .padding(.top, 5)
//                    // Current Time Display
//                    Text(getTime())
//                        .font(.timeText)
//                        .padding(.top,10)
//
//                    Spacer(minLength: 0)
//                }
//                .onAppear(perform: updateTime)
//                .onReceive(receiver) { _ in
//                    updateTime()
//                }
//
//            }
//        }
//    }
    var body: some View {
            ZStack {
                Color.backgroundColor.ignoresSafeArea()
                GeometryReader { geometryReader in
                    VStack {
                        // Clock UI Components
                        createClockUI(geometryReader: geometryReader)

                        // Enhanced Timezone Selection Button
                        Button(action: {
                            showingTimeZonePicker = true
                        }) {
                            HStack {
                                Text("Select Timezone")
                                    .foregroundColor(.white)
                                Image(systemName: "globe")
                                    .foregroundColor(.white)
                            }
                            .padding()
                            .background(Color.blue)
                            .cornerRadius(8)
                            .padding(.top, 10)
                        }
                        .sheet(isPresented: $showingTimeZonePicker) {
                            TimeZonePicker(selectedTimeZone: $selectedTimeZone)
                        }

                        // Display Selected Time Zone
                        Text(selectedTimeZone.identifier)
                            .font(.subheadline)
                            .padding(.top, 5)

                        // Current Time Display
                        Text(getTime())
                            .font(.timeText)
                            .padding(.top, 10)

                        Spacer(minLength: 0)
                    }
                    .onAppear(perform: updateTime)
                    .onReceive(receiver) { _ in
                        updateTime()
                    }
                }
            }
        }

    private func createClockUI(geometryReader: GeometryProxy) -> some View {
        let width = geometryReader.size.width - Constraint.marginLeading - Constraint.marginTrailing
        let numberWidth = width - Constraint.numberPadding
        
        return ZStack {
            ClockView(count: 60, longDivider: 5, longTickHeight: Constraint.longTickHeight, tickHeight: Constraint.tickHeight, tickWidth: Constraint.tickWidth, highlightedColorDivider: 20, highlightedColor: .clockHighlightedLineColor, normalColor: .clockLineColor)
                .frame(width: width, height: width)
            
            NumberView(numbers: getNumbers(count: 12), textColor: .clockTextColor, font: .clockText)
                .frame(width: numberWidth, height: numberWidth)
            
            // NeedleViews for hours, minutes, and seconds
            // NeedleViews for hours, minutes, and seconds
            NeedleView(width: Constraint.needleViewWidth, height: numberWidth * 0.5, color: .needleGeneral, bottomLineHeight: Constraint.needleViewBottomLineHeight)
                .rotationEffect(.degrees((Double(current_Time.hour) + Double(current_Time.min) / 60)) * 30)

            NeedleView(width: Constraint.needleViewWidth, height: numberWidth * 0.75, color: .needleGeneral, bottomLineHeight: Constraint.needleViewBottomLineHeight)
                .rotationEffect(.degrees(Double(current_Time.min) * 6))

            NeedleView(width: Constraint.needleViewWidth, height: numberWidth - 10, color: .needleGeneral, bottomLineHeight: Constraint.needleViewBottomLineHeight)
                .rotationEffect(.degrees(Double(current_Time.sec) * 6))

        }
        .padding(.leading, Constraint.marginLeading)
        .padding(.trailing, Constraint.marginTrailing)
        .padding(.top, Constraint.marginTop)
    }
    
    private func getNumbers(count: Int) -> [Int] {
        var numbers: [Int] = []
        numbers.append(count)
        for index in 1..<count {
            numbers.append(index)
        }
        return numbers
    }
    
    func getTime() -> String {
        let format = DateFormatter()
        format.dateFormat = "hh:mm:ss a"
        format.timeZone = selectedTimeZone
        return format.string(from: Date())
    }
    
    private func updateTime() {
        let calender = Calendar.current
        let min = calender.component(.minute, from: Date())
        let sec = calender.component(.second, from: Date())
        let hour = calender.component(.hour, from: Date())
        
        withAnimation(Animation.linear(duration: 0.01)) {
            self.current_Time = Time(min: min, sec: sec, hour: hour)
        }
    }
//    struct TimeZonePicker: View {
//        @Binding var selectedTimeZone: TimeZone
//        let timezones = TimeZone.knownTimeZoneIdentifiers
//
//        var body: some View {
//            List(timezones, id: \.self) { timezone in
//                Button(timezone) {
//                    selectedTimeZone = TimeZone(identifier: timezone) ?? TimeZone.current
//                }
//            }
//        }
//    }
    struct TimeZonePicker: View {
        @Binding var selectedTimeZone: TimeZone
        @Environment(\.presentationMode) var presentationMode // To dismiss the view
        let timezones = TimeZone.knownTimeZoneIdentifiers
        
        var body: some View {
            List(timezones, id: \.self) { timezone in
                Button(timezone) {
                    selectedTimeZone = TimeZone(identifier: timezone) ?? TimeZone.current
                    presentationMode.wrappedValue.dismiss() // Dismiss the view
                }
                .foregroundColor(selectedTimeZone.identifier == timezone ? .blue : .primary) // Mark the selected time zone
            }
        }
    }

    struct TimeWatchView_Previews: PreviewProvider {
        static var previews: some View {
            TimeWatchView()
        }
    }
}
