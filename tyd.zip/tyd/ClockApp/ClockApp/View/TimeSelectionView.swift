//
//  TimeSelectionView.swift
//  ClockApp
//
//  Created by Bernardo Sa on 12/10/23.
//

import Foundation


struct TimeSelectionView: View {
    @Binding var selectedTime: Date
    var onSave: () -> Void
    var onCancel: () -> Void

    var body: some View {
        VStack {
            DatePicker("Select Time", selection: $selectedTime, displayedComponents: .hourAndMinute)
                .datePickerStyle(WheelDatePickerStyle())

            HStack {
                Button("Cancel", action: onCancel)
                Spacer()
                Button("Save", action: onSave)
            }
            .padding()
        }
        .padding()
    }
}
