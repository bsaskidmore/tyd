////
////  AlarmWatchView.swift
////  ClockApp
////
////  //
//
//import SwiftUI
struct TimeSelectionView: View {
    @Binding var selectedTime: Date
    @Binding var selectedDays: [Bool]  // Array to track selected days
    var onSave: () -> Void
    var onCancel: () -> Void

    private let daysOfWeek = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]

    var body: some View {
        VStack {
            DatePicker(" ", selection: $selectedTime, displayedComponents: .hourAndMinute)
                .datePickerStyle(WheelDatePickerStyle())

            // Days of the week selection
            HStack {
//                ForEach(0..<daysOfWeek.count, id: \.self) { index in
//                    Button(action: {
//                        self.selectedDays[index].toggle()
//                    }) {
//                        Text(daysOfWeek[index])
//                            .foregroundColor(selectedDays[index] ? .blue : .gray)
//                    }
//                }
                ForEach(0..<daysOfWeek.count, id: \.self) { index in
                    Button(action: {
                        self.selectedDays[index].toggle()
                    }) {
                        Text(daysOfWeek[index])
                            .frame(minWidth: 44, minHeight: 44) // Ensure a minimum touch target size
                            .foregroundColor(selectedDays[index] ? .white : .gray)
                            .background(selectedDays[index] ? Color.blue : Color.clear)
                            .cornerRadius(10) // Rounded edges
                    }
                }

            }

            HStack {
                Button("Cancel", action: onCancel)
                Spacer()
                Button("Save", action: onSave)
            }
            .padding()
        }
        .padding()
    }
}


import SwiftUI

struct AlarmWatchView: View {
    @ObservedObject var viewModel: AlarmWatchViewModel
    @State private var showingTimePicker = false
    @State private var selectedTime = Date()
    @State private var selectedDays: [Bool] = Array(repeating: false, count: 7)

    var body: some View {
        NavigationView {
            List {
//                ForEach(viewModel.alarms, id: \.id) { alarm in
//                    HStack {
//                        Text("\(alarm.hour):\(alarm.minute) \(alarm.meridium)")
//                        Spacer()
//                        ForEach(0..<alarm.weekdays.count, id: \.self) { index in
//                            if alarm.weekdays[index] {
//                                Text(dayOfWeek(index))
//                                    .foregroundColor(.blue)
//                            }
//                        }
//                        Spacer()
//                        Button("Delete") {
//                            viewModel.deleteAlarm(id: alarm.id)
//                        }
//                    }
                    ForEach(viewModel.alarms, id: \.id) { alarm in
                        HStack {
                            Text("\(alarm.hour):\(alarm.minute) \(alarm.meridium)")
                                .font(.system(size: 12)) // Set a standard font size
                            Spacer()
                            HStack(spacing: 8) { // Add spacing between days for uniformity
                                ForEach(0..<alarm.weekdays.count, id: \.self) { index in
                                    if alarm.weekdays[index] {
                                        Text(self.dayOfWeek(index))
                                            .font(.system(size: 12)) // Adjust font size as needed
                                            .fontWeight(.semibold) // Make it bold for better legibility
                                    }
                                }
                            }
                            Spacer()
                            Button("Delete") {
                                viewModel.deleteAlarm(id: alarm.id)
                            }
                            .font(.system(size: 12)) // Match the font size with the days
                        }
                    

                
                }
                .onDelete(perform: deleteAlarm)
            }
            .navigationBarTitle("Alarms")
            .navigationBarItems(trailing: Button(action: {
                showingTimePicker = true
            }) {
                Text("Add Alarm")
            })
            .sheet(isPresented: $showingTimePicker) {
                TimeSelectionView(selectedTime: $selectedTime, selectedDays: $selectedDays, onSave: {
                    saveAlarm()
                    showingTimePicker = false
                }, onCancel: {
                    showingTimePicker = false
                })
            }
        }
    }

    private func saveAlarm() {
        let calendar = Calendar.current
        let hour = calendar.component(.hour, from: selectedTime)
        let minute = calendar.component(.minute, from: selectedTime)
        let hourString = hour < 10 ? "0\(hour)" : "\(hour)"
        let minuteString = minute < 10 ? "0\(minute)" : "\(minute)"
        let meridium = hour < 12 ? "AM" : "PM"
        let newAlarm = AlarmTime(minute: minuteString, hour: hourString, meridium: meridium, weekdays: selectedDays)
        viewModel.addAlarm(newAlarm)
    }

    private func deleteAlarm(at offsets: IndexSet) {
        offsets.forEach { index in
            viewModel.alarms.remove(at: index)
        }
    }

    private func dayOfWeek(_ index: Int) -> String {
        let days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
        return days[index]
    }
}

//

