import SwiftUI

struct AlarmCreationView: View {
    @Binding var isPresented: Bool
    @ObservedObject var viewModel: AlarmWatchViewModel

    @State private var hour: Int = 12
    @State private var minute: Int = 0
    @State private var isAM: Bool = true
    @State private var selectedWeekdays: [Bool] = Array(repeating: false, count: 7)
    var body: some View {
        NavigationView {
            Form {
                Picker("Hour", selection: $hour) {
                    ForEach(1..<13, id: \.self) { hour in
                        Text("\(hour)").tag(hour)
                    }
                }
                
                Picker("Minute", selection: $minute) {
                    ForEach(0..<60, id: \.self) { minute in
                        Text(String(format: "%02d", minute)).tag(minute)
                    }
                }
                
                Toggle(isOn: $isAM) {
                    Text("AM")
                }

                Button("Save Alarm") {
                    saveAlarm()
                    isPresented = false
                }
            }
            .navigationBarTitle("Create Alarm", displayMode: .inline)
            .navigationBarItems(trailing: Button("Cancel") {
                isPresented = false
            })
        }
    }

    private func saveAlarm() {
        let hourString = String(format: "%02d", hour)
        let minuteString = String(format: "%02d", minute)
        let meridium = isAM ? "AM" : "PM"
        
        // Assuming 'selectedWeekdays' is your [Bool] array representing selected days
        let newAlarm = AlarmTime(minute: minuteString, hour: hourString, meridium: meridium, weekdays: selectedWeekdays)
        viewModel.addAlarm(newAlarm)
    }

}
