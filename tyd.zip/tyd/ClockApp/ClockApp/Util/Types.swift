//
//  Types.swift
//  ClockApp
//
//  
//

import Foundation

enum NeedleType {
    case minute
    case hour
    case none
}

enum LeftButtonType {
    case lapPassive
    case lapActive
    case reset
    case cancel
}

enum LapType {
    case normal
    case best
    case worst
}
