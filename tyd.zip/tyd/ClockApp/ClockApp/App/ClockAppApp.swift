//
//  ClockAppApp.swift
//  ClockApp
//
//  
//

import SwiftUI

@main
struct ClockAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
