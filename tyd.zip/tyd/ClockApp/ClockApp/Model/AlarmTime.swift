import Foundation

struct AlarmTime: Identifiable {
    var id: UUID = UUID()  // Unique identifier for each alarm
    var minute: String
    var hour: String
    var meridium: String
    var weekdays: [Bool]

    init(minute: String, hour: String, meridium: String, weekdays: [Bool]) {
        self.minute = minute
        self.hour = hour
        self.meridium = meridium
        self.weekdays = weekdays
    }

    // Add any additional properties or methods needed for your alarm
}
