//
//  LapItemPresenter.swift
//  ClockApp
//
//  

import Foundation
struct LapItemPresenter: Identifiable {
    
    let id = UUID()
    var lap: String = ""
    var time: String = ""
    var type: LapType = .normal
    
    
}
