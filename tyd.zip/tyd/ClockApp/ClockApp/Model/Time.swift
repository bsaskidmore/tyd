//
//  Time.swift
//  ClockApp
//
//  
//

import Foundation
struct Time {
    var min : Int
    var sec : Int
    var hour : Int
}
