//
//  AlertOption.swift
//  ClockApp
//
//  
//

import Foundation
struct AlertOption {
    let id = UUID()
    var type: AlertType = .none
    var message: String = ""
}
enum AlertType: String {
    case success = "Success"
    case error = "Error"
    case none = ""
}
