import Foundation

class TimerViewModel: ObservableObject {
    @Published var remainingTime: TimeInterval
    var totalDuration: TimeInterval
    var timer: Timer?
    @Published var selectedHours: Int = 0
        @Published var selectedMinutes: Int = 0
        @Published var selectedSeconds: Int = 0


    init() {
        // Initialize with default values or load from saved state
        self.remainingTime = 3600 // Example: 1 hour
        self.totalDuration = 3600
    }

    func startTimer() {
        stopTimer() // Stop any existing timer

        // Start a new timer
        let totalSeconds = (selectedHours * 3600) + (selectedMinutes * 60) + selectedSeconds
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in
            guard let self = self else { return }

            if self.remainingTime > 0 {
                self.remainingTime -= 1
            } else {
                self.stopTimer()
                // Add any actions to perform when the timer finishes
            }
        }
    }

    func stopTimer() {
        timer?.invalidate()
        timer = nil
    }

    func resetTimer() {
        stopTimer()
        remainingTime = totalDuration // Reset to the initial duration
    }

    func setTimer(hours: Int, minutes: Int, seconds: Int) {
        let newDuration = TimeInterval(hours * 3600 + minutes * 60 + seconds)
        totalDuration = newDuration
        remainingTime = newDuration
    }
    func setTimerDuration(_ seconds: Int) {
            // Set the timer duration here
            // This will be your countdown time
            remainingTime = TimeInterval(seconds)
            totalDuration = TimeInterval(seconds)
        }
}
