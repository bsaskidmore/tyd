import Foundation
import UserNotifications

class AlarmWatchViewModel: ObservableObject {
    @Published var alarms = [AlarmTime]()
    private let center = UNUserNotificationCenter.current()

    init() {
        requestNotificationPermission()
        // Load existing alarms if you're storing them persistently
    }

    private func requestNotificationPermission() {
        center.requestAuthorization(options: [.alert, .badge, .sound]) { granted, error in
            if let error = error {
                print("Error requesting notification permission: \(error.localizedDescription)")
            }
            // Handle the granted permission
        }
    }

    func addAlarm(_ newAlarm: AlarmTime) {
        alarms.append(newAlarm)
        scheduleNotification(for: newAlarm)
        // Save alarms to persistent storage if needed
    }

    func deleteAlarm(id: UUID) {
        if let index = alarms.firstIndex(where: { $0.id == id }) {
            cancelNotification(for: alarms[index])
            alarms.remove(at: index)
            // Update persistent storage if needed
        }
    }

    private func scheduleNotification(for alarm: AlarmTime) {
        // Here, add logic to schedule a notification based on the alarm
        // Use UserNotifications framework to schedule local notifications
    }

    private func cancelNotification(for alarm: AlarmTime) {
        // Add logic to cancel the notification corresponding to the alarm
        // You would typically use the identifier to cancel the notification
    }

    // Additional methods to handle notifications (scheduling and canceling) can be added here
}
